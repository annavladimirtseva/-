package main2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Main implements ActionListener {

public Main() {
initComponents();
}

private JFrame viewForm;

private void initComponents() {
viewForm = new JFrame("Моя программа");
viewForm.setSize(400, 300);
viewForm.setVisible(true);
viewForm.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

JButton but = new JButton("Начать работу");
but.setVisible(true);
but.setLocation(120, 50);
but.setSize(150, 50);

JButton button = new JButton("Подробнее");
button.setVisible(true);
button.setLocation(120,150);
button.setSize(150, 50);
button.addActionListener(new ActionListener() {



public void actionPerformed(ActionEvent e) {

new Izfile21("Текст", 120, 800);

}

});
viewForm.getContentPane().add(button);
viewForm.getContentPane().add(new JLabel());
viewForm.getContentPane().add(but);
viewForm.getContentPane().add(new JLabel());
}

public void actionPerformed(ActionEvent action) {
}

public static void main(String[] args) {
SwingUtilities.invokeLater(new Runnable() {
public void run() {
new Main();
}
});
}
}